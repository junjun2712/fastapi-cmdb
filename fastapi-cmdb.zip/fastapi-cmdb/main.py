from datetime import timedelta
from fastapi import FastAPI, Request, Depends, status, Form, Response, Path
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.encoders import jsonable_encoder
from starlette.status import HTTP_400_BAD_REQUEST
from db import SessionLocal, engine, DBContext
import models, crud, schemas
from sqlalchemy.orm import Session
from fastapi_login import LoginManager
from dotenv import load_dotenv
import os
from passlib.context import CryptContext
from fastapi.responses import RedirectResponse
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.responses import HTMLResponse, RedirectResponse, ORJSONResponse
from sqlalchemy import and_,or_,func

load_dotenv()
SECRET_KEY = os.getenv('SECRET_KEY')
ACCESS_TOKEN_EXPIRE_MINUTES=60

manager = LoginManager(SECRET_KEY, token_url="/login", use_cookie=True)
manager.cookie_name = "auth"

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

app = FastAPI()
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

def get_db():
    with DBContext() as db:
        yield db

def get_hashed_password(plain_password):
    return pwd_ctx.hash(plain_password)

def verify_password(plain_password, hashed_password):
    return pwd_ctx.verify(plain_password,hashed_password)

@manager.user_loader
def get_user(username: str, db: Session = None):
    if db is None:
        with DBContext() as db:
            return crud.get_user_by_username(db=db,username=username)
    return crud.get_user_by_username(db=db,username=username)

def authenticate_user(username: str, password: str, db: Session = Depends(get_db)):
    user = crud.get_user_by_username(db=db,username=username)
    if not user:
        return None
    if not verify_password(plain_password=password,hashed_password=user.hashed_password):
        return None
    return user

class NotAuthenticatedException(Exception):
    pass


    
def not_authenticated_exception_handler(request, exception):
    return RedirectResponse("/login")

manager.not_authenticated_exception = NotAuthenticatedException
app.add_exception_handler(NotAuthenticatedException, not_authenticated_exception_handler)




@app.get("/login")
def root(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "title": "Home"})

@app.get("/tasks")
def get_tasks(request: Request, db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    return templates.TemplateResponse("tasks.html", {"request": request, 
    "title": "Tasks", 
    "user": user, 
    "tasks": crud.get_tasks_by_user_id(db=db,id=user.id)})

@app.post("/tasks")
def add_task(request: Request, text: str = Form(...), db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    added = crud.add_task(db=db,task=schemas.TaskCreate(text=text),id=user.id)
    if not added:
        return templates.TemplateResponse("tasks.html", {"request": request,
        "title": "Tasks",
        "user": user,
        "tasks": crud.get_tasks_by_user_id(db=db,id=user.id),
        "invalid": True}, status_code=status.HTTP_400_BAD_REQUEST)
    else:
        return RedirectResponse("/tasks", status_code=status.HTTP_302_FOUND)
        
############################################################################################################################################ 
#serverlist
#show serverlist   
@app.get("/tasks/hostlist")
def get_hostlist(request: Request, db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    total_name = str(db.query(func.count(models.Hostinfo.name)).all()).strip('[()\n]').replace(" ","").replace(",","")
    return templates.TemplateResponse("hostlist.html", {"request": request, "title": "Tasks", "user": user, "total":total_name, "tasks": db.query(models.Hostinfo).all()})

#search    
@app.post("/tasks/hostlist")
def get_search(request: Request,search: str = Form(...),db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    total_name = str(db.query(func.count(models.Hostinfo.name)).all()).strip('[()\n]').replace(" ","").replace(",","")
    return templates.TemplateResponse("hostlist.html", {"request": request,
    "total": total_name,
    "tasks": db.query(models.Hostinfo).filter(or_(models.Hostinfo.ip.like("%" + search + "%"),
                      models.Hostinfo.idc.like("%" + search + "%"),
                      models.Hostinfo.name.like("%" + search + "%"),
                      models.Hostinfo.owner.like("%" + search + "%"))).all()})
    
                      

############################################################################################################################################ 
#servermanage
#show servermanage if admin 

@app.get("/tasks/servermanage")
def get_servermanage(request: Request, db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    user_admin = db.query(models.User).filter(and_(models.User.flag == 1),(models.User.username == user.username)).all()
    #print(type(user_admin))
    print(user_admin)
    print(user.username)
    #if  user_admin == user.username:
    if not user_admin :
        return RedirectResponse("/tasks")
    else:
        
        return templates.TemplateResponse("servermanage.html", {"request": request, "title": "Tasks", "user": user, "tasks": db.query(models.Hostinfo).all()})
#search    
@app.post("/tasks/servermanage")
def get_search(request: Request,search: str = Form(...),db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    return templates.TemplateResponse("servermanage.html", {"request": request,
    "tasks": db.query(models.Hostinfo).filter(or_(models.Hostinfo.ip.like("%" + search + "%"),
                      models.Hostinfo.idc.like("%" + search + "%"),
                      models.Hostinfo.name.like("%" + search + "%"),
                      models.Hostinfo.owner.like("%" + search + "%"))).all()})
############################################################################################################################################     
#usermanage
#show usermanage if admin 

@app.get("/tasks/usermanage")
def get_servermanage(request: Request, db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    user_admin = db.query(models.User).filter(and_(models.User.flag == 1),(models.User.username == user.username)).all()
    #print(type(user_admin))
    print(user_admin)
    print(user.username)
    #if  user_admin == user.username:
    if not user_admin :
        return RedirectResponse("/tasks")
    else:
        
        return templates.TemplateResponse("usermanage.html", {"request": request, "title": "Tasks", "tasks": db.query(models.User).all()})
        
#add user    
@app.get("/tasks/usermanage/add_user")
def get_add_user(request: Request, db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    return templates.TemplateResponse("add_user.html", {"request": request, "title": "Register"})
    
@app.post("/tasks/usermanage/add_user")
def add_user(request: Request,
username: str = Form(...),
password: str = Form(...),
flag: str = Form(...),
role: str = Form(...),
db: Session = Depends(get_db)):
    hashed_password = get_hashed_password(password)
    invalid = False

    
    if not invalid:
        
        crud.create_user(db=db, user=schemas.UserCreate(username=username,hashed_password=hashed_password,flag=flag,role=role))
        response = RedirectResponse("/tasks/usermanage", status_code=status.HTTP_302_FOUND)
        return response
    else:
        return templates.TemplateResponse("add_user.html",{"request": request, "title": "Register", "invalid": True},
        status_code=HTTP_400_BAD_REQUEST)
#del user
@app.get("/tasks/usermanage/{id}", response_class=RedirectResponse)
def delete_user(id: str = Path(...), db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    crud.delete_user(db=db,id=id)
    return RedirectResponse("/tasks/usermanage")    

############################################################################################################################################     


@app.get("/tasks/delete/{id}", response_class=RedirectResponse)
def delete_task(id: str = Path(...), db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    crud.delete_task(db=db,id=id)
    return RedirectResponse("/tasks")
    
@app.get("/tasks/servermanage/{id}", response_class=RedirectResponse)
def delete_host(id: str = Path(...), db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    crud.delete_host(db=db,id=id)
    return RedirectResponse("/tasks/servermanage")    
    
############################################################################################################################################            
@app.get("/login")
def get_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "title": "Login"})

@app.post("/login")
def login(request: Request, form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = authenticate_user(username=form_data.username,password=form_data.password,db=db)
    if not user:
        return templates.TemplateResponse("login.html", {"request": request,
        "title": "Login",
        "invalid": True}, status_code=status.HTTP_401_UNAUTHORIZED)
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = manager.create_access_token(
        data={"sub": user.username},
        expires=access_token_expires
    )
    resp = RedirectResponse("/tasks/hostlist", status_code=status.HTTP_302_FOUND)
    manager.set_cookie(resp,access_token)
    return resp
############################################################################################################################################        
@app.get("/register")
def get_register(request: Request):
    return templates.TemplateResponse("register.html", {"request": request, "title": "Register"})

@app.post("/register")
def register(request: Request,
username: str = Form(...),
email: str = Form(...),
name: str = Form(...),
password: str = Form(...),
db: Session = Depends(get_db)):
    hashed_password = get_hashed_password(password)
    invalid = False
    if crud.get_user_by_username(db=db,username=username):
        invalid = True
    if crud.get_user_by_email(db=db,email=email):
        invalid = True
    
    if not invalid:
        crud.create_user(db=db, user=schemas.UserCreate(username=username,email=email,name=name,hashed_password=hashed_password))
        response = RedirectResponse("/login", status_code=status.HTTP_302_FOUND)
        return response
    else:
        return templates.TemplateResponse("register.html",{"request": request, "title": "Register", "invalid": True},
        status_code=HTTP_400_BAD_REQUEST)
        
############################################################################################################################################
#ADD_HOST        
@app.get("/tasks/servermanage/add_host")
def get_add_host(request: Request, db: Session = Depends(get_db), user: schemas.User = Depends(manager)):
    return templates.TemplateResponse("add_host.html", {"request": request, "title": "Register"})

@app.post("/tasks/servermanage/add_host")
def add_host(request: Request,
name: str = Form(...),
ip: str = Form(...),
os: str = Form(...),
cpu: str = Form(...),
mem: str = Form(...),
hdd: str = Form(...),
idc: str = Form(...),
owner: str = Form(...),
db: Session = Depends(get_db)):

    invalid = False

    
    if not invalid:
        
        crud.add_host(db=db, hostinfo=schemas.HostinfoCreate(name=name,ip=ip,os=os,cpu=cpu,mem=mem,hdd=hdd,idc=idc,owner=owner))
        response = RedirectResponse("/tasks/servermanage", status_code=status.HTTP_302_FOUND)
        return response
    else:
        return templates.TemplateResponse("add_host.html",{"request": request, "title": "Register", "invalid": True},
        status_code=HTTP_400_BAD_REQUEST)
############################################################################################################################################ 



@app.get("/logout")
def logout(response: Response):
    response = RedirectResponse("/login")
    manager.set_cookie(response,None)
    return response
    
@app.get("/")
def logout(response: Response):
    response = RedirectResponse("/login")
    manager.set_cookie(response,None)
    return response