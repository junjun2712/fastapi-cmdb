from pydantic import BaseModel
from typing import List, Optional

class TaskBase(BaseModel):
    text: str

class Task(TaskBase):
    id: str
    user_id: str

    class Config:
        orm_mode = True

class TaskCreate(TaskBase):
    pass

class UserBase(BaseModel):
    username: str

    hashed_password: str
    flag: str
    role: str
    
class User(UserBase):
    id: str
    tasks: List[Task] = []

    class Config:
        orm_mode = True

class UserCreate(UserBase):
    pass
    

class HostinfoBase(BaseModel):
    name: str
    ip: str
    os: str
    cpu: str
    mem: str
    hdd: str
    idc: str
    owner: str

class Hostinfo(HostinfoBase):
    id: str
    name: str

    class Config:
        orm_mode = True
    

class HostinfoCreate(HostinfoBase):
    pass