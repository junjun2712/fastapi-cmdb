from sqlalchemy import String, Column, ForeignKey, Integer
from sqlalchemy.orm import relationship
from db import Base

class User(Base):
    __tablename__ = "user"
    id = Column(String, primary_key=True, index=True,nullable=False)
    email = Column(String, unique=True, index=True,nullable=False)
    name = Column(String, index=True)
    username = Column(String, unique=True, index=True,nullable=False)
    hashed_password = Column(String,nullable=False)
    flag = Column(String, unique=True, index=True,nullable=False)
    role = Column(String, unique=True, index=True,nullable=False)
    items = relationship("Task", back_populates="user")

class Task(Base):
    __tablename__ = "task"

    id = Column(String, primary_key=True, index=True, nullable=False)
    text = Column(String, index=True, nullable=False)
    user_id = Column(String, ForeignKey("user.id"), nullable=False)

    user = relationship("User", back_populates="items")
    
class Hostinfo(Base):
    __tablename__ = "hostinfo"
    id = Column(String, primary_key=True, index=True,nullable=False)
    name = Column(String, index=True, nullable=False)
    ip = Column(String, index=True, nullable=False)
    os  = Column(String, index=True, nullable=False)
    cpu = Column(String, index=True, nullable=False)
    mem = Column(String, index=True, nullable=False)
    hdd = Column(String, index=True, nullable=False)
    idc = Column(String, index=True, nullable=False)
    owner = Column(String, index=True, nullable=False)
   